import { useState } from 'react';
import { ShoppingBag, Heart, Eye, Filter } from 'lucide-react';

interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  category: string;
  emoji: string;
  bgColor: string;
  badge?: string;
  isNew?: boolean;
  rating: number;
}

const products: Product[] = [
  {
    id: 1,
    name: 'Rose Petal Scrunchie',
    price: 149,
    originalPrice: 199,
    category: 'Scrunchies',
    emoji: '🎀',
    bgColor: 'from-rose-light to-peach',
    badge: 'Bestseller',
    rating: 5,
  },
  {
    id: 2,
    name: 'Lavender Dream Scrunchie',
    price: 149,
    category: 'Scrunchies',
    emoji: '💜',
    bgColor: 'from-lavender to-blush',
    isNew: true,
    rating: 4,
  },
  {
    id: 3,
    name: 'Sunset Ombre Scrunchie',
    price: 179,
    category: 'Scrunchies',
    emoji: '🌅',
    bgColor: 'from-peach to-lavender',
    rating: 5,
  },
  {
    id: 4,
    name: 'Classic Teddy Bear',
    price: 599,
    originalPrice: 699,
    category: 'Teddy Bears',
    emoji: '🧸',
    bgColor: 'from-cream-dark to-peach',
    badge: 'Popular',
    rating: 5,
  },
  {
    id: 5,
    name: 'Mini Bunny',
    price: 449,
    category: 'Teddy Bears',
    emoji: '🐰',
    bgColor: 'from-blush to-lavender',
    isNew: true,
    rating: 5,
  },
  {
    id: 6,
    name: 'Cute Kitty Amigurumi',
    price: 549,
    category: 'Teddy Bears',
    emoji: '🐱',
    bgColor: 'from-lavender to-rose-light',
    rating: 4,
  },
  {
    id: 7,
    name: 'Boho Headband',
    price: 249,
    originalPrice: 299,
    category: 'Headbands',
    emoji: '👒',
    bgColor: 'from-sage/20 to-cream-dark',
    badge: 'Sale',
    rating: 4,
  },
  {
    id: 8,
    name: 'Flower Crown Headband',
    price: 299,
    category: 'Headbands',
    emoji: '🌸',
    bgColor: 'from-rose-light to-blush',
    isNew: true,
    rating: 5,
  },
  {
    id: 9,
    name: 'Ear Warmer Headband',
    price: 279,
    category: 'Headbands',
    emoji: '🧣',
    bgColor: 'from-peach to-cream-dark',
    rating: 4,
  },
  {
    id: 10,
    name: 'Crop Top — Summer Breeze',
    price: 899,
    originalPrice: 1099,
    category: 'Clothes',
    emoji: '👚',
    bgColor: 'from-blush to-lavender',
    badge: 'Trending',
    rating: 5,
  },
  {
    id: 11,
    name: 'Cozy Cardigan',
    price: 1499,
    category: 'Clothes',
    emoji: '🧥',
    bgColor: 'from-cream-dark to-rose-light',
    rating: 5,
  },
  {
    id: 12,
    name: 'Cropped Vest',
    price: 799,
    category: 'Clothes',
    emoji: '🦺',
    bgColor: 'from-sage/20 to-blush',
    isNew: true,
    rating: 4,
  },
  {
    id: 13,
    name: 'Mini Tote Bag',
    price: 499,
    category: 'Bags',
    emoji: '👜',
    bgColor: 'from-peach to-rose-light',
    rating: 4,
  },
  {
    id: 14,
    name: 'Coin Purse',
    price: 299,
    category: 'Bags',
    emoji: '👛',
    bgColor: 'from-lavender to-cream-dark',
    rating: 5,
  },
  {
    id: 15,
    name: 'Coaster Set (4 pcs)',
    price: 399,
    category: 'Home Decor',
    emoji: '🪑',
    bgColor: 'from-sage/20 to-lavender',
    rating: 4,
  },
  {
    id: 16,
    name: 'Keychain — Mini Heart',
    price: 99,
    category: 'Accessories',
    emoji: '🔑',
    bgColor: 'from-rose-light to-peach',
    badge: '₹99 Only',
    rating: 5,
  },
  {
    id: 17,
    name: 'Beanie — Winter Vibes',
    price: 349,
    category: 'Accessories',
    emoji: '🧢',
    bgColor: 'from-lavender to-rose-light',
    rating: 4,
  },
  {
    id: 18,
    name: 'Phone Pouch',
    price: 349,
    category: 'Accessories',
    emoji: '📱',
    bgColor: 'from-blush to-peach',
    isNew: true,
    rating: 4,
  },
];

const categories = ['All', 'Scrunchies', 'Teddy Bears', 'Headbands', 'Clothes', 'Bags', 'Home Decor', 'Accessories'];

export default function Products() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [wishlist, setWishlist] = useState<number[]>([]);

  const filteredProducts =
    activeCategory === 'All'
      ? products
      : products.filter((p) => p.category === activeCategory);

  const toggleWishlist = (id: number) => {
    setWishlist((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  return (
    <section id="products" className="py-16 sm:py-24 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-cream via-white to-cream-dark" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-8 sm:mb-12">
          <span className="inline-flex items-center gap-2 text-rose-primary font-semibold text-sm tracking-widest uppercase">
            <ShoppingBag className="w-4 h-4" />
            Our Collection
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-brown-dark">
            Handmade <span className="text-rose-primary">Creations</span>
          </h2>
          <div className="section-divider" />
          <p className="text-brown-warm max-w-2xl mx-auto text-base sm:text-lg">
            Each piece is lovingly handcrafted stitch by stitch. Browse our collection and find something that speaks to your heart.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-10 sm:mb-14">
          <Filter className="w-5 h-5 text-brown-warm self-center mr-1 hidden sm:block" />
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 sm:px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                activeCategory === cat
                  ? 'bg-gradient-to-r from-rose-primary to-rose-dark text-white shadow-lg shadow-rose-primary/25'
                  : 'bg-white text-brown-warm hover:bg-rose-light/50 hover:text-rose-dark border border-rose-light/50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-4 sm:gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="product-card bg-white rounded-2xl sm:rounded-3xl overflow-hidden border border-rose-light/30"
            >
              {/* Image Area */}
              <div className={`relative bg-gradient-to-br ${product.bgColor} aspect-square flex items-center justify-center overflow-hidden`}>
                {/* Replace this div with your product image: <img src="..." /> */}
                <span className="product-image text-6xl sm:text-7xl select-none">
                  {product.emoji}
                </span>

                {/* Badge */}
                {product.badge && (
                  <span className="absolute top-3 left-3 bg-rose-dark text-white text-[10px] sm:text-xs px-2.5 py-1 rounded-full font-bold shadow-md">
                    {product.badge}
                  </span>
                )}

                {/* New Badge */}
                {product.isNew && (
                  <span className="absolute top-3 left-3 bg-sage-dark text-white text-[10px] sm:text-xs px-2.5 py-1 rounded-full font-bold shadow-md">
                    NEW ✨
                  </span>
                )}

                {/* Wishlist Button */}
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className="absolute top-3 right-3 w-8 h-8 sm:w-9 sm:h-9 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors shadow-sm"
                >
                  <Heart
                    className={`w-4 h-4 sm:w-5 sm:h-5 transition-colors ${
                      wishlist.includes(product.id)
                        ? 'text-rose-primary fill-rose-primary'
                        : 'text-brown-warm/50'
                    }`}
                  />
                </button>

                {/* Quick View Overlay */}
                <div className="absolute inset-0 bg-brown-dark/0 group-hover:bg-brown-dark/10 transition-colors flex items-center justify-center opacity-0 hover:opacity-100">
                  <button className="bg-white/90 backdrop-blur-sm rounded-full p-3 shadow-lg hover:scale-110 transition-transform">
                    <Eye className="w-5 h-5 text-brown-dark" />
                  </button>
                </div>
              </div>

              {/* Details */}
              <div className="p-3 sm:p-4 space-y-1.5 sm:space-y-2">
                {/* Rating */}
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <span
                      key={i}
                      className={`text-xs ${
                        i < product.rating ? 'text-yellow-400' : 'text-gray-200'
                      }`}
                    >
                      ★
                    </span>
                  ))}
                </div>

                <h3 className="font-display text-sm sm:text-base font-semibold text-brown-dark line-clamp-1">
                  {product.name}
                </h3>

                <div className="flex items-center gap-2">
                  <span className="text-rose-primary font-bold text-base sm:text-lg">
                    ₹{product.price}
                  </span>
                  {product.originalPrice && (
                    <span className="text-brown-warm/50 line-through text-xs sm:text-sm">
                      ₹{product.originalPrice}
                    </span>
                  )}
                </div>

                <a
                  href="https://wa.me/YOUR_NUMBER"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full text-center bg-gradient-to-r from-rose-primary to-rose-dark text-white py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-semibold hover:shadow-lg hover:shadow-rose-primary/20 transition-all duration-300 hover:scale-[1.02]"
                >
                  Order on WhatsApp
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Note about images */}
        <div className="mt-10 sm:mt-14 text-center bg-rose-light/30 rounded-2xl p-6 sm:p-8 border border-rose-light/50">
          <p className="text-brown-warm text-sm sm:text-base">
            📸 <strong>Note:</strong> Product images shown are placeholders. Replace the emoji placeholders with your actual product photos to showcase your beautiful crochet creations!
          </p>
        </div>
      </div>
    </section>
  );
}
