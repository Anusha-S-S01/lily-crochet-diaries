import { Heart, Scissors, Palette, Truck } from 'lucide-react';

const features = [
  {
    icon: Heart,
    title: 'Made with Love',
    description: 'Every stitch is crafted with passion and care, making each piece uniquely special.',
    emoji: '💕',
  },
  {
    icon: Scissors,
    title: '100% Handmade',
    description: 'No machines, no mass production. Each item is carefully handcrafted by skilled artisans.',
    emoji: '🧶',
  },
  {
    icon: Palette,
    title: 'Custom Designs',
    description: 'Want something unique? We bring your vision to life with custom colors and patterns.',
    emoji: '🎨',
  },
  {
    icon: Truck,
    title: 'Pan-India Delivery',
    description: 'We ship across India with care. Your handmade treasure will reach you safely.',
    emoji: '📦',
  },
];

export default function About() {
  return (
    <section id="about" className="py-16 sm:py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-cream-dark via-cream to-white" />
      <div className="absolute top-0 left-0 right-0 crochet-border" />
      
      {/* Background decorations */}
      <div className="absolute top-20 right-0 w-72 h-72 bg-blush/30 rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-0 w-64 h-64 bg-lavender/20 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-12 sm:mb-16">
          <span className="inline-flex items-center gap-2 text-rose-primary font-semibold text-sm tracking-widest uppercase">
            💫 Our Story
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-brown-dark">
            About <span className="text-rose-primary font-script">Lily</span> Crochet Diaries
          </h2>
          <div className="section-divider" />
        </div>

        {/* Story Section */}
        <div className="grid lg:grid-cols-2 gap-10 sm:gap-16 items-center mb-16 sm:mb-24">
          {/* Image Placeholder */}
          <div className="relative">
            <div className="aspect-[4/5] rounded-3xl bg-gradient-to-br from-rose-light via-blush to-peach flex items-center justify-center shadow-xl shadow-rose-primary/10 overflow-hidden">
              <div className="text-center space-y-3 p-6">
                <span className="text-8xl sm:text-9xl">🧶</span>
                <p className="font-script text-rose-dark text-lg sm:text-xl">Your Photo Here</p>
                <p className="text-brown-warm/60 text-sm">Replace with your workspace or portrait photo</p>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -bottom-4 -right-4 w-24 h-24 sm:w-32 sm:h-32 bg-sage/20 rounded-3xl -z-10" />
            <div className="absolute -top-4 -left-4 w-20 h-20 sm:w-24 sm:h-24 bg-peach/30 rounded-3xl -z-10" />
          </div>

          {/* Story Text */}
          <div className="space-y-6">
            <h3 className="font-display text-2xl sm:text-3xl font-bold text-brown-dark">
              Where Every Stitch Tells a <span className="text-rose-primary">Story</span>
            </h3>
            <div className="space-y-4 text-brown-warm leading-relaxed text-sm sm:text-base">
              <p>
                Welcome to Lily Crochet Diaries! 🌸 What started as a small hobby has blossomed 
                into a passion for creating beautiful, handmade crochet items that bring joy to 
                people's lives.
              </p>
              <p>
                From cute amigurumi teddy bears to trendy scrunchies, from stylish headbands to 
                cozy cardigans — every piece is made with love, patience, and the finest yarns. 
                I believe that handmade items carry a special warmth that factory-made products 
                simply cannot replicate.
              </p>
              <p>
                Each creation at Lily Crochet Diaries is unique, just like you! Whether you're 
                looking for a gift, a treat for yourself, or something custom-made, I'm here to 
                craft it for you with all my heart. 💕
              </p>
            </div>
            <a
              href="https://wa.me/YOUR_NUMBER"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-rose-primary to-rose-dark text-white px-6 py-3 rounded-full font-semibold hover:shadow-xl hover:shadow-rose-primary/20 transition-all duration-300 hover:scale-105"
            >
              Let's Create Together 🧶
            </a>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-3xl p-6 sm:p-8 text-center border border-rose-light/30 hover:border-rose-primary/30 hover:shadow-xl hover:shadow-rose-primary/5 transition-all duration-500 hover:-translate-y-2 group"
            >
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                {feature.emoji}
              </div>
              <h4 className="font-display text-lg font-bold text-brown-dark mb-2">
                {feature.title}
              </h4>
              <p className="text-brown-warm text-sm leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div className="mt-16 sm:mt-24">
          <div className="text-center space-y-4 mb-10 sm:mb-14">
            <h3 className="font-display text-2xl sm:text-3xl font-bold text-brown-dark">
              What Our <span className="text-rose-primary">Customers</span> Say
            </h3>
            <div className="section-divider" />
          </div>

          <div className="grid sm:grid-cols-3 gap-6">
            {[
              {
                name: 'Priya S.',
                text: 'The teddy bear I ordered was absolutely adorable! The quality and attention to detail were amazing. Will definitely order again! 🧸❤️',
                rating: 5,
              },
              {
                name: 'Ananya R.',
                text: "I love the scrunchies! They are so soft and don't damage my hair at all. The colors are beautiful too. Highly recommend! 🎀",
                rating: 5,
              },
              {
                name: 'Meera K.',
                text: 'Got a custom cardigan made and it fits perfectly! The craftsmanship is incredible. Lily Crochet Diaries is the best! 🧥✨',
                rating: 5,
              },
            ].map((testimonial, index) => (
              <div
                key={index}
                className="bg-white rounded-3xl p-6 sm:p-8 border border-rose-light/30 hover:shadow-lg transition-shadow duration-300"
              >
                <div className="flex gap-0.5 mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <span key={i} className="text-yellow-400">★</span>
                  ))}
                </div>
                <p className="text-brown-warm text-sm sm:text-base leading-relaxed mb-4 italic">
                  "{testimonial.text}"
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-rose-light to-peach flex items-center justify-center text-sm font-bold text-rose-dark">
                    {testimonial.name[0]}
                  </div>
                  <div>
                    <p className="font-semibold text-brown-dark text-sm">{testimonial.name}</p>
                    <p className="text-brown-warm/60 text-xs">Verified Customer</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
