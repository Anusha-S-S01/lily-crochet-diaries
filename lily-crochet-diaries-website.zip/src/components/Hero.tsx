import { ArrowDown, Sparkles } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 yarn-texture" />
      <div className="absolute top-20 left-10 w-72 h-72 bg-blush/40 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-lavender/30 rounded-full blur-3xl" />
      <div className="absolute top-1/3 right-1/4 w-64 h-64 bg-peach/20 rounded-full blur-3xl" />

      {/* Decorative yarn balls */}
      <div className="absolute top-32 right-16 w-8 h-8 rounded-full bg-rose-primary/20 animate-float hidden lg:block" />
      <div className="absolute top-48 right-32 w-5 h-5 rounded-full bg-sage/30 animate-float delay-300 hidden lg:block" />
      <div className="absolute bottom-40 left-20 w-6 h-6 rounded-full bg-peach/40 animate-float delay-500 hidden lg:block" />
      <div className="absolute bottom-60 left-40 w-10 h-10 rounded-full bg-blush/50 animate-float delay-200 hidden lg:block" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="text-center lg:text-left space-y-6 sm:space-y-8">
            <div className="animate-fade-in-up">
              <span className="inline-flex items-center gap-2 bg-rose-light/60 text-rose-dark px-4 py-2 rounded-full text-sm font-medium">
                <Sparkles className="w-4 h-4" />
                Handcrafted with Love
              </span>
            </div>

            <h1 className="animate-fade-in-up delay-200 font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-brown-dark leading-tight">
              Lily{' '}
              <span className="text-rose-primary relative">
                Crochet
                <svg className="absolute -bottom-2 left-0 w-full" viewBox="0 0 200 12" fill="none">
                  <path d="M2 8 Q50 2 100 8 Q150 14 198 6" stroke="#C4848A" strokeWidth="3" strokeLinecap="round" opacity="0.5" />
                </svg>
              </span>
              <br />
              <span className="font-script font-medium text-sage-dark">Diaries</span>
            </h1>

            <p className="animate-fade-in-up delay-400 text-brown-warm text-base sm:text-lg max-w-lg mx-auto lg:mx-0 leading-relaxed">
              Discover the art of handmade crochet — from adorable amigurumi teddies 
              to stylish scrunchies and cozy wearables. Every stitch tells a story, 
              every piece is made with love. 💕
            </p>

            <div className="animate-fade-in-up delay-600 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <a
                href="#products"
                className="bg-gradient-to-r from-rose-primary to-rose-dark text-white px-8 py-4 rounded-full text-base font-semibold hover:shadow-xl hover:shadow-rose-primary/25 transition-all duration-300 hover:scale-105 flex items-center justify-center gap-2"
              >
                Explore Collection
                <span className="text-lg">🧶</span>
              </a>
              <a
                href="#offers"
                className="border-2 border-rose-primary/40 text-rose-dark px-8 py-4 rounded-full text-base font-semibold hover:bg-rose-light/50 hover:border-rose-primary transition-all duration-300 flex items-center justify-center gap-2"
              >
                Today's Offers
                <span className="text-lg">✨</span>
              </a>
            </div>

            {/* Stats */}
            <div className="animate-fade-in-up delay-800 flex gap-8 justify-center lg:justify-start pt-4">
              <div className="text-center">
                <p className="font-display text-2xl sm:text-3xl font-bold text-brown-dark">500+</p>
                <p className="text-brown-warm text-sm">Happy Customers</p>
              </div>
              <div className="w-px bg-rose-light" />
              <div className="text-center">
                <p className="font-display text-2xl sm:text-3xl font-bold text-brown-dark">1000+</p>
                <p className="text-brown-warm text-sm">Items Crafted</p>
              </div>
              <div className="w-px bg-rose-light" />
              <div className="text-center">
                <p className="font-display text-2xl sm:text-3xl font-bold text-brown-dark">50+</p>
                <p className="text-brown-warm text-sm">Designs</p>
              </div>
            </div>
          </div>

          {/* Hero Image / Placeholder */}
          <div className="animate-fade-in delay-300 relative flex justify-center lg:justify-end">
            <div className="relative">
              {/* Main image placeholder */}
              <div className="w-72 h-72 sm:w-80 sm:h-80 md:w-96 md:h-96 rounded-full bg-gradient-to-br from-rose-light via-blush to-peach flex items-center justify-center shadow-2xl shadow-rose-primary/10">
                <div className="text-center space-y-3">
                  <span className="text-7xl sm:text-8xl">🧶</span>
                  <p className="font-script text-rose-dark text-lg">Your Image Here</p>
                </div>
              </div>

              {/* Floating product cards */}
              <div className="absolute -top-4 -left-4 sm:-left-8 bg-white rounded-2xl shadow-xl p-3 animate-float">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-lg bg-peach/50 flex items-center justify-center text-xl">
                    🧸
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-brown-dark">Teddy Bear</p>
                    <p className="text-xs text-rose-primary font-bold">₹599</p>
                  </div>
                </div>
              </div>

              <div className="absolute -bottom-4 -right-4 sm:-right-8 bg-white rounded-2xl shadow-xl p-3 animate-float delay-500">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-lg bg-lavender/50 flex items-center justify-center text-xl">
                    🎀
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-brown-dark">Scrunchies</p>
                    <p className="text-xs text-rose-primary font-bold">₹149</p>
                  </div>
                </div>
              </div>

              <div className="absolute top-1/2 -right-2 sm:-right-12 bg-white rounded-2xl shadow-xl p-3 animate-float delay-200 hidden sm:block">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-lg bg-rose-light/50 flex items-center justify-center text-xl">
                    👒
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-brown-dark">Headband</p>
                    <p className="text-xs text-rose-primary font-bold">₹249</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <a href="#offers" className="flex flex-col items-center gap-2 text-rose-primary/60 hover:text-rose-primary transition-colors">
          <span className="text-xs font-medium tracking-widest uppercase">Scroll</span>
          <ArrowDown className="w-4 h-4" />
        </a>
      </div>

      {/* Crochet border bottom */}
      <div className="absolute bottom-0 left-0 right-0 crochet-border" />
    </section>
  );
}
