import { Clock, Tag, Gift, Percent, Star } from 'lucide-react';

interface Offer {
  id: number;
  title: string;
  description: string;
  discount: string;
  validFrom: string;
  validTo: string;
  emoji: string;
  bgGradient: string;
  tagColor: string;
}

const offers: Offer[] = [
  {
    id: 1,
    title: 'Summer Scrunchie Sale',
    description: 'Buy 3 Scrunchies & Get 1 Free! Mix and match from our beautiful collection.',
    discount: '25% OFF',
    validFrom: 'June 1, 2025',
    validTo: 'June 30, 2025',
    emoji: '🎀',
    bgGradient: 'from-peach to-rose-light',
    tagColor: 'bg-rose-primary text-white',
  },
  {
    id: 2,
    title: 'Teddy Bear Bonanza',
    description: 'Our adorable handmade amigurumi teddies at special prices this season!',
    discount: '₹100 OFF',
    validFrom: 'June 15, 2025',
    validTo: 'July 15, 2025',
    emoji: '🧸',
    bgGradient: 'from-lavender to-blush',
    tagColor: 'bg-brown-warm text-white',
  },
  {
    id: 3,
    title: 'Combo Deal — Headband + Scrunchie Set',
    description: 'Get a matching headband and scrunchie set at a bundled price!',
    discount: '₹199 Only',
    validFrom: 'June 10, 2025',
    validTo: 'June 25, 2025',
    emoji: '🎁',
    bgGradient: 'from-blush to-peach',
    tagColor: 'bg-sage-dark text-white',
  },
  {
    id: 4,
    title: 'First Order Discount',
    description: 'New to Lily Crochet Diaries? Welcome! Enjoy a special discount on your first order.',
    discount: '15% OFF',
    validFrom: 'Always',
    validTo: 'No Expiry',
    emoji: '✨',
    bgGradient: 'from-rose-light to-lavender',
    tagColor: 'bg-rose-dark text-white',
  },
];

export default function Offers() {
  return (
    <section id="offers" className="py-16 sm:py-24 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-cream via-white to-cream" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-12 sm:mb-16">
          <span className="inline-flex items-center gap-2 text-rose-primary font-semibold text-sm tracking-widest uppercase">
            <Tag className="w-4 h-4" />
            Special Offers
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-brown-dark">
            Today's <span className="text-rose-primary">Best Deals</span>
          </h2>
          <div className="section-divider" />
          <p className="text-brown-warm max-w-2xl mx-auto text-base sm:text-lg">
            Don't miss out on our limited-time offers! Each piece is handmade with care — grab yours before they're gone.
          </p>
        </div>

        {/* Offers Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {offers.map((offer, index) => (
            <div
              key={offer.id}
              className={`offer-card bg-gradient-to-br ${offer.bgGradient} rounded-3xl p-6 relative group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2`}
              style={{ animationDelay: `${index * 150}ms` }}
            >
              {/* Discount Badge */}
              <div className={`${offer.tagColor} absolute -top-3 right-4 px-3 py-1 rounded-full text-xs font-bold shadow-lg flex items-center gap-1`}>
                <Percent className="w-3 h-3" />
                {offer.discount}
              </div>

              {/* Emoji Icon */}
              <div className="text-5xl mb-4 group-hover:scale-110 transition-transform duration-300">
                {offer.emoji}
              </div>

              {/* Content */}
              <h3 className="font-display text-lg font-bold text-brown-dark mb-2">
                {offer.title}
              </h3>
              <p className="text-brown-warm text-sm leading-relaxed mb-4">
                {offer.description}
              </p>

              {/* Validity */}
              <div className="flex items-center gap-2 text-xs text-brown-warm/70 bg-white/40 rounded-xl px-3 py-2">
                <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                <span>
                  {offer.validFrom} — {offer.validTo}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Banner CTA */}
        <div className="mt-12 sm:mt-16 bg-gradient-to-r from-rose-primary via-rose-dark to-brown-warm rounded-3xl p-8 sm:p-12 text-center text-white relative overflow-hidden">
          <div className="absolute inset-0 animate-shimmer" />
          <div className="relative">
            <div className="flex items-center justify-center gap-2 mb-3">
              <Star className="w-5 h-5 fill-yellow-300 text-yellow-300" />
              <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
              <Star className="w-5 h-5 fill-yellow-300 text-yellow-300" />
            </div>
            <h3 className="font-display text-2xl sm:text-3xl font-bold mb-3">
              Custom Orders Welcome!
            </h3>
            <p className="text-white/80 max-w-xl mx-auto mb-6 text-sm sm:text-base">
              Want something unique? We love bringing your ideas to life! DM us on Instagram or WhatsApp to discuss your custom crochet piece.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://wa.me/YOUR_NUMBER"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 bg-white text-rose-dark px-6 py-3 rounded-full font-semibold hover:bg-cream transition-colors"
              >
                <Gift className="w-4 h-4" />
                WhatsApp Us
              </a>
              <a
                href="https://instagram.com/YOUR_HANDLE"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 border-2 border-white/50 text-white px-6 py-3 rounded-full font-semibold hover:bg-white/10 transition-colors"
              >
                📸 Instagram
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
