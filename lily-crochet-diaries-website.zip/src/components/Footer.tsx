import { Heart, MessageCircle, Mail, ArrowUp, MapPin } from 'lucide-react';

const InstagramIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
  </svg>
);

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="contact" className="relative">
      {/* CTA Section */}
      <div className="bg-gradient-to-r from-rose-primary via-rose-dark to-brown-warm py-12 sm:py-16">
        <div className="max-w-4xl mx-auto px-4 text-center text-white">
          <h3 className="font-display text-2xl sm:text-3xl md:text-4xl font-bold mb-4">
            Ready to Order? 💕
          </h3>
          <p className="text-white/80 text-sm sm:text-base max-w-xl mx-auto mb-8">
            Drop us a message on WhatsApp or Instagram, and we will get back to you within hours. Custom orders are always welcome!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/YOUR_NUMBER"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 text-white px-8 py-4 rounded-full font-semibold text-base transition-all duration-300 hover:scale-105 shadow-lg"
            >
              <MessageCircle className="w-5 h-5" />
              WhatsApp Us
            </a>
            <a
              href="mailto:YOUR_EMAIL@example.com"
              className="inline-flex items-center justify-center gap-2 bg-white/20 hover:bg-white/30 text-white px-8 py-4 rounded-full font-semibold text-base transition-all duration-300 border border-white/30"
            >
              <Mail className="w-5 h-5" />
              Email Us
            </a>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="bg-brown-dark text-white/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-10">
            {/* Brand */}
            <div className="sm:col-span-2 lg:col-span-1 space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-rose-primary to-rose-dark flex items-center justify-center">
                  <Heart className="w-5 h-5 text-white fill-white" />
                </div>
                <div>
                  <span className="font-display text-lg font-bold text-white block leading-tight">
                    Lily
                  </span>
                  <span className="font-script text-sm text-rose-primary -mt-1 block leading-tight">
                    Crochet Diaries
                  </span>
                </div>
              </div>
              <p className="text-white/60 text-sm leading-relaxed">
                Handcrafted with love, stitch by stitch. Making the world cozier, one crochet at a time. 🧶
              </p>
              <div className="flex gap-3">
                {/* Instagram */}
                <a
                  href="https://instagram.com/YOUR_HANDLE"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-white/10 hover:bg-gradient-to-br hover:from-purple-500 hover:to-pink-500 flex items-center justify-center transition-all duration-300 hover:scale-110"
                  aria-label="Instagram"
                >
                  <InstagramIcon className="w-5 h-5" />
                </a>
                {/* WhatsApp */}
                <a
                  href="https://wa.me/YOUR_NUMBER"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-white/10 hover:bg-green-500 flex items-center justify-center transition-all duration-300 hover:scale-110"
                  aria-label="WhatsApp"
                >
                  <MessageCircle className="w-5 h-5" />
                </a>
                {/* Email */}
                <a
                  href="mailto:YOUR_EMAIL@example.com"
                  className="w-10 h-10 rounded-full bg-white/10 hover:bg-rose-primary flex items-center justify-center transition-all duration-300 hover:scale-110"
                  aria-label="Email"
                >
                  <Mail className="w-5 h-5" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-display text-white font-semibold text-base mb-4">
                Quick Links
              </h4>
              <ul className="space-y-3">
                {['Home', 'Offers', 'Products', 'About', 'Contact'].map((link) => (
                  <li key={link}>
                    <a
                      href={`#${link.toLowerCase()}`}
                      className="text-white/60 hover:text-rose-primary text-sm transition-colors duration-300 flex items-center gap-2"
                    >
                      <span className="w-1 h-1 rounded-full bg-rose-primary/50" />
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Categories */}
            <div>
              <h4 className="font-display text-white font-semibold text-base mb-4">
                Categories
              </h4>
              <ul className="space-y-3">
                {['Scrunchies', 'Teddy Bears', 'Headbands', 'Clothes', 'Bags', 'Accessories'].map((cat) => (
                  <li key={cat}>
                    <a
                      href="#products"
                      className="text-white/60 hover:text-rose-primary text-sm transition-colors duration-300 flex items-center gap-2"
                    >
                      <span className="w-1 h-1 rounded-full bg-sage/50" />
                      {cat}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h4 className="font-display text-white font-semibold text-base mb-4">
                Get in Touch
              </h4>
              <ul className="space-y-4">
                <li>
                  <a
                    href="https://wa.me/YOUR_NUMBER"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-3 text-white/60 hover:text-green-400 transition-colors text-sm group"
                  >
                    <MessageCircle className="w-5 h-5 flex-shrink-0 mt-0.5 group-hover:text-green-400" />
                    <div>
                      <p className="font-medium text-white/80">WhatsApp</p>
                      <p className="text-xs">+91 YOUR_NUMBER</p>
                    </div>
                  </a>
                </li>
                <li>
                  <a
                    href="mailto:YOUR_EMAIL@example.com"
                    className="flex items-start gap-3 text-white/60 hover:text-rose-primary transition-colors text-sm group"
                  >
                    <Mail className="w-5 h-5 flex-shrink-0 mt-0.5 group-hover:text-rose-primary" />
                    <div>
                      <p className="font-medium text-white/80">Email</p>
                      <p className="text-xs">YOUR_EMAIL@example.com</p>
                    </div>
                  </a>
                </li>
                <li>
                  <a
                    href="https://instagram.com/YOUR_HANDLE"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-3 text-white/60 hover:text-purple-400 transition-colors text-sm group"
                  >
                    <InstagramIcon className="w-5 h-5 flex-shrink-0 mt-0.5 group-hover:text-purple-400" />
                    <div>
                      <p className="font-medium text-white/80">Instagram</p>
                      <p className="text-xs">@YOUR_HANDLE</p>
                    </div>
                  </a>
                </li>
                <li className="flex items-start gap-3 text-white/60 text-sm">
                  <MapPin className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-white/80">Location</p>
                    <p className="text-xs">India 🇮🇳</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-white/40 text-xs sm:text-sm text-center sm:text-left">
              © {new Date().getFullYear()} Lily Crochet Diaries. All rights reserved. Made with{' '}
              <Heart className="w-3 h-3 inline text-rose-primary fill-rose-primary" /> and 🧶
            </p>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-2 text-white/40 hover:text-rose-primary text-xs sm:text-sm transition-colors group"
            >
              Back to Top
              <ArrowUp className="w-4 h-4 group-hover:-translate-y-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
