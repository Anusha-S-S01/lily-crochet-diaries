import { useState, useEffect } from 'react';
import { Menu, X, Heart } from 'lucide-react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Offers', href: '#offers' },
    { name: 'Products', href: '#products' },
    { name: 'About', href: '#about' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-white/90 backdrop-blur-md shadow-lg shadow-rose-primary/5'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-2 group">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br from-rose-primary to-rose-dark flex items-center justify-center shadow-md group-hover:shadow-lg group-hover:shadow-rose-primary/30 transition-shadow">
              <Heart className="w-4 h-4 sm:w-5 sm:h-5 text-white fill-white" />
            </div>
            <div className="flex flex-col">
              <span className="font-display text-lg sm:text-xl font-bold text-brown-dark leading-tight">
                Lily
              </span>
              <span className="font-script text-xs sm:text-sm text-rose-primary -mt-1 leading-tight">
                Crochet Diaries
              </span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="nav-link text-brown-dark/80 hover:text-rose-primary font-medium text-sm tracking-wide transition-colors duration-300"
              >
                {link.name}
              </a>
            ))}
            <a
              href="#products"
              className="bg-gradient-to-r from-rose-primary to-rose-dark text-white px-5 py-2.5 rounded-full text-sm font-semibold hover:shadow-lg hover:shadow-rose-primary/30 transition-all duration-300 hover:scale-105"
            >
              Shop Now
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-rose-light/50 transition-colors"
          >
            {isOpen ? (
              <X className="w-6 h-6 text-brown-dark" />
            ) : (
              <Menu className="w-6 h-6 text-brown-dark" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden transition-all duration-500 overflow-hidden ${
          isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="bg-white/95 backdrop-blur-md border-t border-rose-light px-4 py-4 space-y-1">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={() => setIsOpen(false)}
              className="block py-3 px-4 text-brown-dark/80 hover:text-rose-primary hover:bg-rose-light/30 rounded-lg font-medium transition-all duration-300"
            >
              {link.name}
            </a>
          ))}
          <a
            href="#products"
            onClick={() => setIsOpen(false)}
            className="block text-center mt-3 bg-gradient-to-r from-rose-primary to-rose-dark text-white px-5 py-3 rounded-full font-semibold hover:shadow-lg transition-all duration-300"
          >
            Shop Now
          </a>
        </div>
      </div>
    </nav>
  );
}
