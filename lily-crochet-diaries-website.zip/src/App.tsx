import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Offers from './components/Offers';
import Products from './components/Products';
import About from './components/About';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-cream text-brown-dark overflow-x-hidden">
      <Navbar />
      <Hero />
      <Offers />
      <Products />
      <About />
      <Footer />
    </div>
  );
}
